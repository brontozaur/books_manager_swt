///****************************************************************************
//* Copyright (c) 2006-2008 Jeremy Dowdall
//* All rights reserved. This program and the accompanying materials
//* are made available under the terms of the Eclipse Public License v1.0
//* which accompanies this distribution, and is available at
//* http://www.eclipse.org/legal/epl-v10.html
//*
//* Contributors:
//*    Jeremy Dowdall <jeremyd@aspencloud.com> - initial API and implementation
//*****************************************************************************/
//
//package org.aspencloud.cdatetime;
//
//
//import java.util.Date;
//
//import org.eclipse.core.runtime.ListenerList;
//import org.eclipse.jface.util.SafeRunnable;
//import org.eclipse.jface.viewers.ISelection;
//import org.eclipse.jface.viewers.ISelectionChangedListener;
//import org.eclipse.jface.viewers.ISelectionProvider;
//import org.eclipse.jface.viewers.IStructuredSelection;
//import org.eclipse.jface.viewers.SelectionChangedEvent;
//import org.eclipse.jface.viewers.StructuredSelection;
//import org.eclipse.swt.events.SelectionEvent;
//import org.eclipse.swt.events.SelectionListener;
//import org.eclipse.swt.widgets.Composite;
//
//public class CDateTimeSelectionProvider implements ISelectionProvider, SelectionListener {
//
//	private CDateTime cdt;
//	private ListenerList selectionChangedListeners = new ListenerList(ListenerList.IDENTITY);
//	
//	public CDateTimeSelectionProvider(CDateTime cdt) {
//		this.cdt = cdt;
//		cdt.addSelectionListener(this);
//	}
//
//	public CDateTimeSelectionProvider(Composite parent, int style) {
//		cdt = new CDateTime(parent, style);
//		cdt.addSelectionListener(this);
//	}
//	
//	public void addSelectionChangedListener(ISelectionChangedListener listener) {
//		selectionChangedListeners.add(listener);
//	}
//
//    /**
//     * Notifies any selection changed listeners that the viewer's selection has changed.
//     * Only listeners registered at the time this method is called are notified.
//     *
//     * @param event a selection changed event
//     *
//     * @see ISelectionChangedListener#selectionChanged
//     */
//    private void fireSelectionChanged(final SelectionChangedEvent event) {
//        Object[] listeners = selectionChangedListeners.getListeners();
//        for (int i = 0; i < listeners.length; ++i) {
//            final ISelectionChangedListener l = (ISelectionChangedListener) listeners[i];
//            SafeRunnable.run(new SafeRunnable() {
//                public void run() {
//                    l.selectionChanged(event);
//                }
//            });
//        }
//    }
//
//    public AbstractCombo getCDateTime() {
//		return cdt;
//	}
//	
//	public ISelection getSelection() {
//		return new StructuredSelection(cdt.getSelectedDates());
//	}
//
//	public void removeSelectionChangedListener(ISelectionChangedListener listener) {
//		selectionChangedListeners.remove(listener);
//	}
//
//	public void setSelection(ISelection selection) {
//		if(!selection.isEmpty() && (selection instanceof IStructuredSelection)) {
//			Object obj = ((IStructuredSelection) selection).getFirstElement();
//			if(obj instanceof Date) {
//				cdt.setSelection((Date) obj);
//			}
//		}
//	}
//
//	public void widgetDefaultSelected(SelectionEvent event) {
//		IStructuredSelection sel = new StructuredSelection(cdt.getSelectedDates());
//		SelectionChangedEvent sce = new SelectionChangedEvent(this, sel);
//		fireSelectionChanged(sce);
//	}
//
//	public void widgetSelected(SelectionEvent event) {
//		IStructuredSelection sel = new StructuredSelection(cdt.getSelectedDates());
//		SelectionChangedEvent e = new SelectionChangedEvent(this, sel);
//		fireSelectionChanged(e);
//	}
//
//}
