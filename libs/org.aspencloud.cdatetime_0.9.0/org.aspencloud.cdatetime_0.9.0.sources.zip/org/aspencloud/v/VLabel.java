/****************************************************************************
* Copyright (c) 2008 Jeremy Dowdall
* All rights reserved. This program and the accompanying materials
* are made available under the terms of the Eclipse Public License v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* Contributors:
*    Jeremy Dowdall <jeremyd@aspencloud.com> - initial API and implementation
*****************************************************************************/

package org.aspencloud.v;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;

public class VLabel extends VControl {

	public VLabel(VPanel panel, int style) {
		super(panel, style | SWT.NO_FOCUS);
		if(hasStyle(SWT.SEPARATOR)) {
			setMargins(0, 0);
		}
		setPainter(new VLabelPainter());
	}
	
	@Override
	public Point computeSize(int wHint, int hHint, boolean changed) {
		if(hasStyle(SWT.SEPARATOR)) {
			return new Point(2,2);
		} else {
			return super.computeSize(wHint, hHint, changed);
		}
	}
	
	@Override
	public Type getType() {
		return VControl.Type.Label;
	}

	@Override
	public void setBounds(int x, int y, int width, int height) {
		super.setBounds(
				x,
				y,
				(hasStyle(SWT.SEPARATOR) && !hasStyle(SWT.HORIZONTAL)) ? 2 : width,
				(hasStyle(SWT.SEPARATOR) && hasStyle(SWT.HORIZONTAL)) ? 2 : height
			);
	}

}
