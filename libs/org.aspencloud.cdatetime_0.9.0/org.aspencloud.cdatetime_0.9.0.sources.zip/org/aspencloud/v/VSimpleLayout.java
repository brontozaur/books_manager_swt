package org.aspencloud.v;

import org.eclipse.swt.graphics.Point;

public class VSimpleLayout extends VLayout {

	@Override
	protected Point computeSize(VPanel panel, int wHint, int hHint, boolean flushCache) {
		Point size = new Point(panel.marginLeft+panel.marginRight, panel.marginTop+panel.marginBottom);
		
		VControl[] children = panel.getChildren();
		if(children.length > 0) {
			Point childSize = children[0].computeSize(wHint, hHint, flushCache);
			size.x += childSize.x;
			size.y += childSize.y;
		}
		
		return size;
	}

	@Override
	protected void layout(VPanel panel, boolean flushCache) {
		VControl[] children = panel.getChildren();
		if(children.length > 0) {
			children[0].setBounds(panel.getClientArea());
			if(children[0] instanceof VPanel) {
				((VPanel) children[0]).layout(flushCache);
			}
		}
	}

}
