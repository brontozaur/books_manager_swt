/****************************************************************************
* Copyright (c) 2005-2006 Jeremy Dowdall
* All rights reserved. This program and the accompanying materials
* are made available under the terms of the Eclipse Public License v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* Contributors:
*    Jeremy Dowdall <jeremyd@aspencloud.com> - initial API and implementation
*****************************************************************************/

package org.aspencloud.widgets.cnumpad;

import java.util.HashMap;
import java.util.Map;

import org.aspencloud.widgets.CButton;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;



public class CNumPad extends Composite {

	public static final int STYLE_PHONE = 1;

	public static final String[] FUNCS 	= { "Bksp", "Clr", "Accept", "Cancel" };
	
	public static final int KEYPAD	 	= -1;
	public static final int FUNC_BKSP 	= 0;
	public static final int FUNC_CLR 	= 1;
	public static final int FUNC_ACCEPT 	= 2;
	public static final int FUNC_CANCEL 	= 3;
	
	Composite keypad;
	Composite funcpad;
	
	CButton[] keys = new CButton[12];
	Map keyMap = new HashMap(12);
	CButton[] funcs = new CButton[4];
	CButton BKSP 	= funcs[0];
	CButton CLR 		= funcs[1];
	CButton ACCEPT 	= funcs[2];
	CButton CANCEL 	= funcs[3];
	
	private Listener listener = new Listener() {
		public void handleEvent(Event event) {
			switch (event.type) {
			case SWT.KeyDown:
				CButton b = (CButton) keyMap.get(Integer.toString(event.keyCode));
				if(b == null) {
					switch (event.keyCode) {
					case '\b':
						b = BKSP;
						break;
					case '\r':
					case '\n':
					case SWT.KEYPAD_CR:
						b = ACCEPT;
						break;
					case SWT.ESC:
						b = CANCEL;
						break;
					}
				}
				if(b != null) {
					b.setSelection(true);
					Event e = new Event();
					e.type = SWT.Selection;
					e.widget = b;
					e.button = 1;
					e.display = event.display;
					e.gc = event.gc;
					b.notifyListeners(SWT.Selection, e);
				}
				break;
			case SWT.Selection:
				Event e = new Event();
				e.widget = CNumPad.this;
				e.button = event.button;
				e.data = event.widget.getData("Key");
				if(FUNCS[FUNC_ACCEPT] == e.data) {
					e.detail = FUNC_ACCEPT;
				} else if(FUNCS[FUNC_BKSP] == e.data) {
					e.detail = FUNC_BKSP;
					e.keyCode = '\b';
				} else if(FUNCS[FUNC_CANCEL] == e.data) {
					e.detail = FUNC_CANCEL;
				} else if(FUNCS[FUNC_CLR] == e.data) {
					e.detail = FUNC_CLR;
				} else {
					e.detail = KEYPAD;
					e.text = (String) e.data;
					e.character = e.text.charAt(0);
				}
				e.display = event.display;
				e.gc = event.gc;
				e.item = event.widget;
				e.type = SWT.Selection;
				notifyListeners(SWT.Selection, e);
				break;
			}
		}
	};
	

	public CNumPad(Composite parent, int style) {
		super(parent, style);

		GridLayout layout = new GridLayout(3, false);
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.horizontalSpacing = 0;
		setLayout(layout);
		
		createKeyPad(style);
		
		Label lbl = new Label(this, SWT.SEPARATOR | SWT.VERTICAL);
		lbl.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));
		
		createFuncPad(style);
		
		int[] buttonEvents = { SWT.KeyDown, SWT.Selection };
		for(int i = 0; i < keys.length; i++) {
			for(int j = 0; j < buttonEvents.length; j++) {
				keys[i].getButton().addListener (buttonEvents[j], listener);
			}
		}
		for(int i = 0; i < funcs.length; i++) {
			for(int j = 0; j < buttonEvents.length; j++) {
				funcs[i].getButton().addListener (buttonEvents[j], listener);
			}
		}
	}

	private void createKeyPad(int style) {
		keypad = new Composite(this, SWT.NONE);
		GridLayout layout = new GridLayout(3, true);
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.horizontalSpacing = 0;
		layout.verticalSpacing = 0;
		keypad.setLayout(layout);
		keypad.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		String[] na;
		if((style & STYLE_PHONE) != 0) {
			na = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", ""  };
		} else {
			na = new String[] { "7", "8", "9", "4", "5", "6", "1", "2", "3", "", "0", ""  };
		}

		for(int i = 0; i < na.length; i++) {
			keys[i] = new CButton(keypad, SWT.PUSH);
			keys[i].setText(na[i]);
			keys[i].setSquare(true);
			keys[i].setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
			keys[i].setData("Key", na[i]);
			keyMap.put(na[i], keys[i].getButton());
		}
		
		keys[9].setEnabled(false);
		keys[11].setEnabled(false);
	}
	
	private void createFuncPad(int style) {
		funcpad = new Composite(this, SWT.NONE);
		funcpad.setLayout(new FillLayout(SWT.VERTICAL));
		funcpad.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false));
		
		funcs[0] = new CButton(funcpad, SWT.ARROW | SWT.LEFT);
		funcs[0].setToolTipText("Backspace");
		funcs[0].setSquare(true);
		funcs[0].getButton().setData("Key", FUNCS[FUNC_BKSP]);

		funcs[1] = new CButton(funcpad, SWT.PUSH);
		funcs[1].setText("Clr");
		funcs[1].setToolTipText("Clear");
		funcs[1].setSquare(true);
		funcs[1].getButton().setData("Key", FUNCS[FUNC_CLR]);

		funcs[2] = new CButton(funcpad, SWT.OK);
		funcs[2].setToolTipText("Accept");
		funcs[2].setSquare(true);
		funcs[2].setData("Key", FUNCS[FUNC_ACCEPT]);

		funcs[3] = new CButton(funcpad, SWT.CANCEL);
		funcs[3].setToolTipText("Cancel");
		funcs[3].setSquare(true);
		funcs[3].setData("Key", FUNCS[FUNC_CANCEL]);
	}

	public void setBackground(Color color) {
		keypad.setBackground(color);
		funcpad.setBackground(color);
		for(int i = 0; i < keys.length; i++) {
			keys[i].setBackground(color);
		}
		for(int i = 0; i < funcs.length; i++) {
			funcs[i].setBackground(color);
		}
		super.setBackground(color);
	}

	public void setForeground(Color color) {
		keypad.setForeground(color);
		funcpad.setForeground(color);
		for(int i = 0; i < keys.length; i++) {
			keys[i].setForeground(color);
		}
		for(int i = 0; i < funcs.length; i++) {
			funcs[i].setForeground(color);
		}
		super.setForeground(color);
	}
}
