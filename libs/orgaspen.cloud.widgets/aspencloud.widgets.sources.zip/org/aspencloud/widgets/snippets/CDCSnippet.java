package org.aspencloud.widgets.snippets;

import java.util.Locale;

import org.aspencloud.widgets.ACW;
import org.aspencloud.widgets.cdatepicker.CDatepickerCombo;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class CDCSnippet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("ACW");
		shell.setLayout(new GridLayout());
		
		GridLayout layout = new GridLayout(2, true);
		shell.setLayout(layout);

		final CDatepickerCombo cdc1 = new CDatepickerCombo(shell, ACW.BORDER);
		cdc1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		final CDatepickerCombo cdc2 = new CDatepickerCombo(shell, ACW.BORDER | ACW.DROP_DOWN);
		cdc2.getCDatepicker().setGridVisible(true);
		cdc2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		
		Label lbl = new Label(shell, SWT.HORIZONTAL | SWT.SEPARATOR);
		GridData data = new GridData(SWT.FILL, SWT.FILL, false, false);
		data.horizontalSpan = 2;
		data.verticalIndent = 15;
		lbl.setLayoutData(data);
		
		final Combo combo1 = new Combo(shell, SWT.BORDER | SWT.RIGHT | SWT.SINGLE);
		combo1.add("Custom Pattern (type in)");
		combo1.add("Date Style: SHORT");
		combo1.add("Date Style: MEDIUM");
		combo1.add("Date Style: LONG");
		combo1.add("DateTime Style: SHORT / SHORT");
		combo1.add("DateTime Style: MEDIUM / MEDIUM");
		combo1.add("DateTime Style: LONG / MEDIUM");
		combo1.add("Time Style: SHORT");
		combo1.add("Time Style: MEDIUM");
		combo1.select(1);
		data = new GridData(SWT.FILL, SWT.FILL, false, false);
		data.horizontalSpan = 2;
		combo1.setLayoutData(data);
		
		Button b = new Button(shell, SWT.PUSH);
		b.setText("Set Format");
		data = new GridData(SWT.RIGHT, SWT.FILL, false, false);
		data.horizontalSpan = 2;
		b.setLayoutData(data);
		b.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				int i = combo1.getSelectionIndex();
				if(i < 1) {
					String pattern = combo1.getText();
					cdc1.setFormat(pattern);
					cdc2.setFormat(pattern);
				} else {
					switch(i) {
					case 1:
						cdc1.setFormat(ACW.DATE_SHORT);
						cdc2.setFormat(ACW.DATE_SHORT);
						break;
					case 2:
						cdc1.setFormat(ACW.DATE_MEDIUM);
						cdc2.setFormat(ACW.DATE_MEDIUM);
						break;
					case 3:
						cdc1.setFormat(ACW.DATE_LONG);
						cdc2.setFormat(ACW.DATE_LONG);
						break;
					case 4:
						cdc1.setFormat(ACW.DATE_SHORT | ACW.TIME_SHORT);
						cdc2.setFormat(ACW.DATE_SHORT | ACW.TIME_SHORT);
						break;
					case 5:
						cdc1.setFormat(ACW.DATE_MEDIUM | ACW.TIME_MEDIUM);
						cdc2.setFormat(ACW.DATE_MEDIUM | ACW.TIME_MEDIUM);
						break;
					case 6:
						cdc1.setFormat(ACW.DATE_LONG | ACW.TIME_MEDIUM);
						cdc2.setFormat(ACW.DATE_LONG | ACW.TIME_MEDIUM);
						break;
					case 7:
						cdc1.setFormat(ACW.DATE_SHORT);
						cdc2.setFormat(ACW.DATE_SHORT);
						break;
					case 8:
						cdc1.setFormat(ACW.DATE_MEDIUM);
						cdc2.setFormat(ACW.DATE_MEDIUM);
						break;
					}
				}
				cdc1.getParent().layout();
			}
		});
		
		final Combo combo2 = new Combo(shell, SWT.DROP_DOWN | SWT.READ_ONLY);
		data = new GridData(SWT.FILL, SWT.FILL, false, false);
		data.horizontalSpan = 2;
		combo2.setLayoutData(data);
		final Locale[] la = Locale.getAvailableLocales();
		Locale local = Locale.getDefault();
		for(int i = 0; i < la.length; i++) {
			combo2.add(la[i].getDisplayName());
			if(la[i].equals(local)) combo2.select(i);
		}
		
		Button bl = new Button(shell, SWT.PUSH);
		bl.setText("Set Locale");
		data = new GridData(SWT.RIGHT, SWT.FILL, false, false);
		data.horizontalSpan = 2;
		bl.setLayoutData(data);
		bl.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Locale locale = Locale.getAvailableLocales()[combo2.getSelectionIndex()];
				cdc1.setLocale(locale);
				cdc2.setLocale(locale);
			}
		});


		
		shell.pack();
		Point size = shell.getSize();
		Rectangle screen = display.getMonitors()[0].getBounds();
		shell.setBounds(
				(screen.width-size.x)/2,
				(screen.height-size.y)/2,
				size.x,
				size.y
				);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
