package org.aspencloud.widgets.snippets;

import java.util.Locale;

import org.aspencloud.widgets.ACW;
import org.aspencloud.widgets.cdatepicker.CDatepicker;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CDSnippet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("ACW");
		shell.setLayout(new GridLayout());
		
		GridLayout layout = new GridLayout();
		shell.setLayout(layout);

		final CDatepicker cd1 = new CDatepicker(shell, ACW.BORDER | ACW.DATE_SHORT | ACW.TIME_MEDIUM);
		cd1.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false));

		final Combo combo1 = new Combo(shell, SWT.BORDER | SWT.RIGHT | SWT.SINGLE);
		combo1.add("Date Style");
		combo1.add("DateTime Style");
		combo1.add("Time Style");
		combo1.select(1);
		GridData data = new GridData(SWT.FILL, SWT.FILL, true, false);
		combo1.setLayoutData(data);
		combo1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				int i = combo1.getSelectionIndex();
				switch(i) {
				case 0:
					cd1.setFormat(ACW.DATE_SHORT);
					break;
				case 1:
					cd1.setFormat(ACW.DATE_SHORT | ACW.TIME_SHORT);
					break;
				case 2:
					cd1.setFormat(ACW.TIME_SHORT);
					break;
				}
				cd1.getParent().layout();
			}
		});
		
		final Combo combo2 = new Combo(shell, SWT.DROP_DOWN | SWT.READ_ONLY);
		data = new GridData(SWT.FILL, SWT.FILL, false, false);
		combo2.setLayoutData(data);
		final Locale[] la = Locale.getAvailableLocales();
		Locale local = Locale.getDefault();
		for(int i = 0; i < la.length; i++) {
			combo2.add(la[i].getDisplayName());
			if(la[i].equals(local)) combo2.select(i);
		}
		combo2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Locale locale = Locale.getAvailableLocales()[combo2.getSelectionIndex()];
				cd1.setLocale(locale);
			}
		});

		final Button b1 = new Button(shell, SWT.CHECK);
		b1.setText("Draw Grid");
		data = new GridData(SWT.RIGHT, SWT.FILL, false, false);
		b1.setLayoutData(data);
		b1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				cd1.setGridVisible(b1.getSelection());
			}
		});
		
		final Button b2 = new Button(shell, SWT.CHECK);
		b2.setText("Show Footer");
		data = new GridData(SWT.RIGHT, SWT.FILL, false, false);
		b2.setLayoutData(data);
		b2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				cd1.setFooterVisible(b2.getSelection());
				cd1.getParent().layout();
			}
		});
		
		shell.pack();
		Point size = shell.getSize();
		Rectangle screen = display.getMonitors()[0].getBounds();
		shell.setBounds(
				(screen.width-size.x)/2,
				(screen.height-size.y)/2,
				size.x,
				size.y
				);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
