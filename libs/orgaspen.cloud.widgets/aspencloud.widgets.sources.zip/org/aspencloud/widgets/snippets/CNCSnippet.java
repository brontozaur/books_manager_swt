package org.aspencloud.widgets.snippets;

import org.aspencloud.widgets.cnumpad.CNumPad;
import org.aspencloud.widgets.cnumpad.CNumPadCombo;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CNCSnippet {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		shell.setText("ACW");
		shell.setLayout(new GridLayout());
		
		GridLayout layout = new GridLayout();
		shell.setLayout(layout);

		final CNumPadCombo cnc = new CNumPadCombo(shell, CNumPad.STYLE_PHONE);
		cnc.setPattern("(###) ###-####");
		cnc.setText("1-800-555-1212");
		cnc.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));

		shell.pack();
		Point size = shell.getSize();
		Rectangle screen = display.getMonitors()[0].getBounds();
		shell.setBounds(
				(screen.width-size.x)/2,
				(screen.height-size.y)/2,
				size.x,
				size.y
				);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
